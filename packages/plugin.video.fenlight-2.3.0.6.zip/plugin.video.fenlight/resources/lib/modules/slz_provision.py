# -*- coding: utf-8 -*-
"""Slzstream TorBox provisioning: fetch API key from operator server after per-device enrollment."""
import uuid

import requests

from caches.settings_cache import get_setting, set_setting
from modules import kodi_utils


def _device_fingerprint():
	fp = get_setting('fenlight.provision.device_fingerprint', '')
	if fp in ('', 'empty_setting', None):
		fp = uuid.uuid4().hex
		set_setting('provision.device_fingerprint', fp)
	return fp


def fetch_torbox_from_provisioning_server():
	base = (get_setting('fenlight.provision.base_url') or '').strip().rstrip('/')
	device_id = (get_setting('fenlight.provision.device_id') or '').strip()
	device_secret = (get_setting('fenlight.provision.device_secret') or '').strip()
	if not base or not device_id or not device_secret:
		return kodi_utils.ok_dialog(
			heading='Slzstream',
			text='Configure provisioning base URL, device ID and device secret first (Accounts tab).',
		)
	url = '%s/v1/provision/torbox' % base
	fp = _device_fingerprint()
	kodi_utils.show_busy_dialog()
	try:
		r = requests.post(
			url,
			json={'device_id': device_id, 'device_secret': device_secret, 'device_fingerprint': fp},
			timeout=30,
		)
	except Exception as e:
		kodi_utils.hide_busy_dialog()
		return kodi_utils.ok_dialog(heading='Slzstream', text='Connection failed.[CR][CR]%s' % str(e))
	kodi_utils.hide_busy_dialog()
	if r.status_code != 200:
		try:
			payload = r.json()
			detail = payload.get('detail', r.text)
			if isinstance(detail, list):
				detail = ' '.join(str(i) for i in detail)
		except Exception:
			detail = r.text or str(r.status_code)
		return kodi_utils.ok_dialog(
			heading='Slzstream',
			text='Provisioning failed (HTTP %s).[CR][CR]%s' % (r.status_code, detail),
		)
	try:
		data = r.json()
		api_key = data.get('torbox_api_key')
	except Exception:
		api_key = None
	if not api_key:
		return kodi_utils.ok_dialog(heading='Slzstream', text='Invalid response from provisioning server (no API key).')
	from apis.torbox_api import TorBoxAPI

	tb = TorBoxAPI()
	tb.token = api_key
	try:
		info = tb.account_info()
		customer = info['data']['customer']
	except Exception:
		return kodi_utils.ok_dialog(heading='Slzstream', text='The key from the server failed TorBox validation.')
	set_setting('tb.token', api_key)
	set_setting('tb.enabled', 'true')
	try:
		from apis.torbox_api import TorBox

		TorBox.clear_cache()
	except Exception:
		pass
	kodi_utils.notification('TorBox authorized via Slzstream', 3000)
	return kodi_utils.ok_dialog(
		heading='Slzstream',
		text='Success. TorBox is enabled on this device.[CR][CR]Account: [B]%s[/B]' % customer,
	)


def reset_provisioning_fingerprint():
	if not kodi_utils.confirm_dialog(
		heading='Slzstream',
		text='Clear the local device fingerprint? Use this after the server cleared enrollment, or to re-bind this Kodi.[CR][CR]Otherwise provisioning may fail.',
		ok_label='Yes',
		cancel_label='No',
	):
		return
	set_setting('provision.device_fingerprint', 'empty_setting')
	kodi_utils.notification('Slzstream fingerprint cleared; a new one will be created on next fetch', 4000)
